#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define BUFFER_SIZE 30000

/* Simple C Server by DeVGaJ */

void handle_client(int new_socket) {
    char buffer[BUFFER_SIZE] = {0};
    long valread = read(new_socket, buffer, BUFFER_SIZE);
    
    // Very basic file reading (serves www/index.html always)
    FILE *html_data;
    html_data = fopen("www/index.html", "r");
    
    char response_data[BUFFER_SIZE];
    
    if (html_data == NULL) {
        char *not_found = "HTTP/1.1 404 Not Found\nContent-Type: text/plain\n\n404: File Not Found";
        write(new_socket, not_found, strlen(not_found));
    } else {
        // Read HTML file into response_data
        fread(response_data, 1, BUFFER_SIZE, html_data);
        fclose(html_data);

        // Construct HTTP Header
        char header[] = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n";
        
        // Send Header then Data
        write(new_socket, header, strlen(header));
        write(new_socket, response_data, strlen(response_data));
    }
    
    printf("------------------\nClient Request:\n%s\n", buffer);
    close(new_socket);
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // 1. Create Socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // 2. Bind to Port
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // 3. Listen
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("🚀 Server listening on port %d...\n", PORT);

    // 4. Accept Connections Loop
    while(1) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept failed");
            exit(EXIT_FAILURE);
        }
        handle_client(new_socket);
    }
    return 0;
}
