function sendToWhatsapp() {
    let number = document.getElementById('number').value;
    let message = document.getElementById('message').value;
    
    // API URL construction
    let url = "https://wa.me/" + number + "?text=" + encodeURIComponent(message);
    
    window.open(url, '_blank').focus();
}
